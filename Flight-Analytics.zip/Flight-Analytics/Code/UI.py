# app.py
import streamlit as st
import pandas as pd
import numpy as np
import altair as alt
from datetime import datetime, date
from Data_Access import DataAccess
import mysql.connector

dataAccess = DataAccess()

def getAirports():
    airports = dataAccess.getData(r"select * from airports")
    #airports.reset_index(drop=True, inplace=True)  
    airports['airport_name'] = airports['iata'] + " - " + airports['Name'] + " " + airports['city'] + ", " + airports['country']
    return airports
    
# -----------------------------
# SIDEBAR: DATA INPUT
# -----------------------------
with st.sidebar:
    st.title("Navigation")
    page = st.radio(
        "Go to",
        [
            "Homepage Dashboard",
            "Search and Filter Flights",
            "Airport Details Viewer",
            "Delay Analysis",
            "DB Queries",
        ],
        index=0,
    )

    st.divider()


# -----------------------------
# MAIN: REQUIRE FLIGHTS DATA
# -----------------------------
st.title("Flights & Airports Dashboard")

# -----------------------------
# PAGE: HOMEPAGE DASHBOARD
# -----------------------------
if page == "Homepage Dashboard":
    st.subheader("Homepage Dashboard")
    
    tot_day = dataAccess.getValue("select count(distinct date(departureSchUTC)) from flights where departureSchUTC is not null")
    tot_airport = dataAccess.getValue("select count(distinct iata) from airports")
    tot_airline = dataAccess.getValue("select count(distinct airlineName) from flights where airlineName is not null")
    tot_flight = dataAccess.getValue("select count(distinct number) from flights")
    
    df = pd.DataFrame({
        "Description" : ['Days of data',"Airport", "Airline","Flights"],
        "Count" : [tot_day, tot_airport,tot_airline, tot_flight]
    })
    
    st.dataframe(df, hide_index=True)
# -----------------------------
# PAGE: SEARCH & FILTER FLIGHTS
# -----------------------------
elif page == "Search and Filter Flights":
    st.subheader("Search and Filter Flights")
    
    dfAirportData = getAirports()
    originAirport = st.selectbox("Select Origin", dfAirportData['airport_name'], width=450)
    desAirport = st.selectbox("Select Departure", dfAirportData[dfAirportData['airport_name']!=originAirport]['airport_name'], width=450)
    
    origin = dfAirportData[dfAirportData['airport_name']==originAirport]['iata'].item()
    dest = dfAirportData[dfAirportData['airport_name']==desAirport]['iata'].item()
    sqlFlightQuery = f"select * from flights where origin='{origin}' and destination='{dest}'"
    
    dfFlight = dataAccess.getData(sqlFlightQuery)
    
    if not dfFlight.empty:
        dfFlight['departureSchUTC'] = dfFlight['departureSchUTC'].apply(pd.to_datetime, errors='coerce')
        
        selDate = st.selectbox("Select Travel Date (UTC)", dfFlight['departureSchUTC'].dt.date.unique(), width=200)
        reqCols = ['number','status','aircraftReg','airlineName','departureSchLocal']
        flights = dfFlight[dfFlight['departureSchUTC'].dt.date == selDate][reqCols]
        
        if not flights.empty: 
            st.caption("Flight details")
            #flights.reset_index(drop=True, inplace=True)  
            sel_event = st.dataframe(flights, on_select="rerun", selection_mode="single-row", hide_index=True)
            sel_indexs = sel_event.selection.rows
            if sel_indexs:
                sqlAircraftQuery = f"select * from aircrafts where reg='{flights.iloc[sel_indexs]["aircraftReg"].item()}'"
                aircraftData = dataAccess.getData(sqlAircraftQuery)
                if not aircraftData.empty:
                    st.caption("Aircraft details")
                    
                    st.dataframe(aircraftData.iloc[0].to_frame(name="value"))
                else:
                    st.caption("Sorry, Aircraft information is not available")
    else:
        st.caption("Sorry, no flights available between the airports")
    
    #st.dataframe(dfFlight)
    

# -----------------------------
# PAGE: AIRPORT DETAILS VIEWER
# -----------------------------
elif page == "Airport Details Viewer":
    st.subheader("Airport Details Viewer")
    
    df = getAirports()
    selAirport = st.selectbox("Select Airport", df['airport_name'], width=400)
    selRow = df[df['airport_name']==selAirport].drop('airport_name', axis=1)
    st.dataframe(selRow.iloc[0].to_frame(name="value"))

# -----------------------------
# PAGE: DELAY ANALYSIS
# -----------------------------
elif page == "Delay Analysis":
    st.subheader("Delay Analysis")
    
    dfAirportData = getAirports()
    selAirport = st.selectbox("Select Airport", dfAirportData['airport_name'], width=450)
    selRec = dfAirportData[dfAirportData['airport_name']==selAirport]
    
    sqlDelayQuery = f"select * from flightdelays where airport = '{selRec['iata'].item()}'"
    
    dfDelays = dataAccess.getData(sqlDelayQuery)
    selDate = st.selectbox("Select Travel Date", dfDelays['travelDate'].unique(), width=200)
    
    #dfDelays.reset_index(drop=True, inplace=True)  
    
    arrivalDelayStats = dfDelays[(dfDelays['travelDate'] == selDate) & (dfDelays['isArrival'] == 1)]
    depDelayStats = dfDelays[(dfDelays['travelDate'] == selDate) & (dfDelays['isArrival'] == 0)]
    
    if not arrivalDelayStats.empty:
        st.caption("Arrival Delay Statistics")
        st.dataframe(arrivalDelayStats.drop(['airport', 'travelDate', 'isArrival'], axis=1), hide_index=True)
        
    if not depDelayStats.empty:
        st.caption("Departure Delay Statistics")
        st.dataframe(depDelayStats.drop(['airport', 'travelDate', 'isArrival'], axis=1), hide_index=True)
    
    
# -----------------------------
# PAGE: DB Queries
# -----------------------------
elif page == "DB Queries":
    st.subheader("DB Queries")
    
    questions = [r"Show the total number of flights for each aircraft model, listing the model and its count.",
                 r"List all aircraft (registration, model) that have been assigned to more than 5 flights.",
                 r"For each airport, display its name and the number of outbound flights, but only for airports with more than 5 flights.",
                 r"Find the top 3 destination airports (name, city) by number of arriving flights, sorted by count descending.",
                 r"Show for each flight: number, origin, destination, and a label 'Domestic' or 'International' using CASE WHEN on country match.",
                 r"Show the 5 most recent arrivals at “DEL” airport including flight number, aircraft, departure airport name, and arrival time, ordered by latest arrival.",
                 r"Find all airports with no arriving flights (never used as a destination in flights table).",
                 r"For each airline, count the number of flights by status (e.g., 'On Time', 'Delayed', 'Cancelled') using CASE WHEN.",
                 r"Show all cancelled flights, with aircraft and both airports, ordered by departure time descending.",
                 r"List all city pairs (origin-destination) that have more than 2 different aircraft models operating flights between them.",
                 r"For each destination airport, compute the % of delayed flights (status='Delayed') among all arrivals, sorted by highest percentage."]
                 
    queries = [r"select a.typename 'Aircraft Type', count(f.number) '# of flights'  from flights f join aircrafts a on f.aircraftReg = a.reg group by a.typename order by a.typename",
               r"select a.reg Registration, a.typename Model from aircrafts a where a.typename in (select a.typename from flights f join aircrafts a on f.aircraftReg = a.reg group by a.typename having count(f.number) > 5)",
               r"select f.origin Airport_IATA, a.Name Airport_Name, count(f.number) outbound_flights from flights f join airports a on f.origin = a.iata group by f.origin,a.Name having count(f.number) > 5",
               r"select a.Name Airport_Name, a.city, count(f.number) inbound_flights from flights f join airports a on f.destination = a.iata group by f.destination,a.Name, a.city order by count(f.number) desc LIMIT 3",
               r"select number, origin, a1.country origin_county,destination, a2.country destination_country, case when a1.country = a2.country then 'Domestic' else 'International' end flight_type from flights f join airports a1 on f.origin = a1.iata join airports a2 on f.destination = a2.iata",
               r"select f.number, a.Name, a.city, a.country, c.typename, arrivalSchUTC, arrivalRevUTC from flights f join airports a on f.destination = a.iata join aircrafts c on f.aircraftreg = c.reg where origin = 'DEL' order by arrivalSchUTC desc limit 5",
               r"select a.* from airports a where a.iata not in ( select distinct destination from flights )",
               r"select f.airlineiata, f.airlineName, count(number) count, status from flights f group by f.airlineiata, f.airlineName, status",
               r"select f.number, f.status, f.origin, f.destination, a.typename aircraft, f.departureschUTC from flights f join aircrafts a on f.aircraftreg = a.reg where status = 'canceled' order by departureSchUTC desc",
               r"select f.origin, f.destination from flights f join aircrafts a on f.aircraftReg = a.reg group by f.origin, f.destination having count(a.model) > 2",
               r"select airport, sum(totalFlights) total_flights, sum(delayedFlights) delayed_flights, (sum(delayedFlights) * 100)/sum(totalFlights) percentage from flightdelays where isArrival = 1 group by airport order by percentage desc"]

    if len(questions) == len(queries):
        df = pd.DataFrame({"question":questions,"query":queries})
        
        selQuestion = st.selectbox("Select question",df['question'])
        query = df[df['question'] == selQuestion]['query'].item()
        st.text_area("Query:", query)
        
        dfResult = dataAccess.getData(query)
        
        st.caption("Query result(s)")
        st.dataframe(dfResult, hide_index=True)
    
    