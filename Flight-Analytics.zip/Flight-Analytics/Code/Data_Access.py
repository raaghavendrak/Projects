import mysql.connector
import pandas as pd

class DataAccess:
    def __init__(self):
        self.conn = mysql.connector.connect(
            host = "localhost",
            user = "root",
            password = "0123456789",
            database = "FlightDB"
        )
        self.cursor = self.conn.cursor()
    
    def getData(self, query):
        df = pd.read_sql(query, self.conn)
        return df
        
    def getValue(self, query):
        self.cursor.execute(query)
        row = self.cursor.fetchone()
        if row:
            return row[0]
    

    