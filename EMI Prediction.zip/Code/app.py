import streamlit as st
import mlflow
import mlflow.pyfunc
import mlflow.sklearn
import pandas as pd
import statsmodels.api as sm
import xgboost as xgb
import numpy as np
import joblib
from xgboost import XGBClassifier, XGBRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, mean_squared_error,classification_report

# Enable autologging
mlflow.sklearn.autolog()
mlflow.xgboost.autolog()

# 1. Configure MLflow (Update URI for remote servers)
mlflow.set_tracking_uri("http://localhost:5000") 
mlflow.set_experiment("Loan Approval System")

st.title("Loan Approval System")

#fetch data
df_emi = pd.read_csv(r"..\Data\emi_prediction_final.csv")

#scale the data
scalar = StandardScaler()
# cols_to_scale = ['age', 'education', 'monthly_salary','years_of_employment',  'house_type', 
#        'credit_score', 'proposed_monthly_emi','expense_to_income', 'liquid_amt']
scaling_cols = ['age', 'monthly_salary',
       'years_of_employment', 'credit_score', 
       'debt_to_income', 'expense_to_income', 'liquid_amt', 'liquidity_ratio',
       'emi_buffer_ratio', 'proposed_monthly_emi']

df_emi[scaling_cols] = scalar.fit_transform( df_emi[scaling_cols])
df_emi['max_monthly_emi'] = np.log1p(df_emi['max_monthly_emi'])

X = df_emi.drop(['emi_eligibility', 'max_monthly_emi'], axis=1)

with st.sidebar:
    
    st.title("Navigation")
    page = st.radio(
        "Go to",
        [
            "Regression Models",
            "Classification Models",
            "Evaluate Loan Application"
        ],
        index=0,
        width='stretch'
    )

    st.divider()

if page == "Regression Models":
    #set target
    y= df_emi['max_monthly_emi']
    #Need to add constant 1
    X_feature = sm.add_constant(X)

    #test train split
    X_train, X_test, y_train, y_test = train_test_split(X_feature, y, test_size=0.30, random_state=42)

    selRegModel = st.selectbox("Select Model", ['Linear Regression','Random Forest Regressor','XGBoost Regressor'], width=200)
    if selRegModel == 'Linear Regression':
        if st.button("Train Model & Log to MLflow"):
            # Start MLflow Run
            with mlflow.start_run() as run:
                # Train model
                model = LinearRegression()
                model.fit(X_train, y_train)

                # Calculate metrics
                y_pred = model.predict(X_test)
                #acc = accuracy_score(y_test, y_pred)
                mse = mean_squared_error(y_test, y_pred)
                #save model
                joblib.dump(model, r"..\model\reg_model.pkl",compress=3)
                # 3. Log to MLflow
                mlflow.log_metric("mse", mse)
                #mlflow.log_metric("accuracy", acc)
                mlflow.sklearn.log_model(model, "linear_reg_model")

                st.success(f"Model trained! MSE : {mse:2f}")
                st.info(f"Run ID: {run.info.run_id}")

    elif selRegModel == 'Random Forest Regressor':

        # Sidebar for Hyperparameters
        st.sidebar.header("Model Parameters")
        n_estimators = st.sidebar.slider("Number of Estimators", 100, 200, 100)
        max_depth = st.sidebar.slider("Max Depth", 5, 20, 15)

        if st.button("Train Model & Log to MLflow"):
            # Start MLflow Run
            with mlflow.start_run() as run:
                # Train model
                model = RandomForestRegressor(n_estimators=n_estimators, max_depth=max_depth, random_state=42)
                model.fit(X_train, y_train)
                
                # Calculate metrics
                y_pred = model.predict(X_test)
                #acc = accuracy_score(y_test, y_pred)
                mse = mean_squared_error(y_test, y_pred)
                #save model
                joblib.dump(model, r"..\model\reg_model.pkl",compress=3)
                # 3. Log to MLflow
                mlflow.log_param("n_estimators", n_estimators)
                mlflow.log_param("max_depth", max_depth)
                mlflow.log_metric("mse", mse)
                #mlflow.log_metric("accuracy", acc)
                mlflow.sklearn.log_model(model, "random_forest_reg_model")

                st.success(f"Model trained! MSE : {mse:2f}")

                st.info(f"Run ID: {run.info.run_id}")

    elif selRegModel == 'XGBoost Regressor':

        # Sidebar for Hyperparameters
        st.sidebar.header("Model Parameters")
        n_estimators = st.sidebar.slider("Number of Estimators", 100, 200, 100)
        learning_rate = st.sidebar.slider("Learning Rate", 0.1, 0.4, 0.2)
        max_depth = st.sidebar.slider("Max Depth", 5, 20, 5)

        if st.button("Train Model & Log to MLflow"):
            # Start MLflow Run
            with mlflow.start_run() as run:
                # Train model
                model = XGBRegressor(n_estimators=n_estimators, max_depth=max_depth,learning_rate = learning_rate)
                model.fit(X_train, y_train)
                
                # Calculate metrics
                y_pred = model.predict(X_test)
                #acc = accuracy_score(y_test, y_pred)
                mse = mean_squared_error(y_test, y_pred)
                #save model
                joblib.dump(model, r"..\model\reg_model.pkl",compress=3)
                # 3. Log to MLflow
                mlflow.log_param("n_estimators", n_estimators)
                mlflow.log_param("max_depth", max_depth)
                mlflow.log_metric("mse", mse)
                #mlflow.log_metric("accuracy", acc)
                mlflow.sklearn.log_model(model, "XGBoost_reg_model")

                st.success(f"Model trained! MSE : {mse:2f}")

                st.info(f"Run ID: {run.info.run_id}")

elif page == "Classification Models":
    #set target
    y= df_emi['emi_eligibility']
    target_names = ['Eligible','High_Risk','Not_Eligible']
    
    #test train split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.30, random_state=42)
    test_df = pd.DataFrame(X_test)
    test_df["target"] = y_test

    selClsModel = st.selectbox("Select Model", ['Logistic Regression','Random Forest Classifier','XGBoost Classifier'], width=300)
    if selClsModel == 'Logistic Regression':
        if st.button("Train Model & Log to MLflow"):
            # Start MLflow Run
            with mlflow.start_run() as run:
                # Train model
                model = LogisticRegression(solver='lbfgs',max_iter=200)
                model.fit(X_train, y_train)

                # Calculate metrics
                y_pred = model.predict(X_test)
                
                report_dict = classification_report(y_test, y_pred, target_names=target_names, output_dict=True)
                report_df = pd.DataFrame(report_dict).transpose()

                # Display the DataFrame using st.dataframe()
                st.dataframe(report_df, use_container_width=True)

                #save model
                joblib.dump(model, r"..\model\cls_model.pkl", compress=3)

                # Log to MLflow
                mlflow.log_dict(report_dict, artifact_file='classification_report.json')

                st.info(f"Run ID: {run.info.run_id}")
       
    elif selClsModel == 'Random Forest Classifier':

        # Sidebar for Hyperparameters
        st.sidebar.header("Model Parameters")
        n_estimators = st.sidebar.slider("Number of Estimators", 100, 200, 100)
        max_depth = st.sidebar.slider("Max Depth", 5, 20, 15)

        if st.button("Train Model & Log to MLflow"):
            # Start MLflow Run
            with mlflow.start_run() as run:
                # Train model
                model = RandomForestClassifier(n_estimators=n_estimators, class_weight='balanced', max_depth=max_depth, random_state=42)
                model.fit(X_train, y_train)
                
                # Calculate metrics
                y_pred = model.predict(X_test)
                report_dict = classification_report(y_test, y_pred, target_names=target_names, output_dict=True)
                report_df = pd.DataFrame(report_dict).transpose()

                #save model
                joblib.dump(model, r"..\model\cls_model.pkl", compress=3)

                # Display the DataFrame using st.dataframe()
                st.dataframe(report_df, use_container_width=True)

                # 3. Log to MLflow
                mlflow.log_param("n_estimators", n_estimators)
                mlflow.log_param("max_depth", max_depth)
                mlflow.log_dict(report_dict, artifact_file='classification_report.json')

                st.info(f"Run ID: {run.info.run_id}")

    elif selClsModel == 'XGBoost Classifier':

        # Sidebar for Hyperparameters
        st.sidebar.header("Model Parameters")
        n_estimators = st.sidebar.slider("Number of Estimators", 100, 200, 100)
        learning_rate = st.sidebar.slider("Learning Rate", 0.1, 0.4, 0.2)
        max_depth = st.sidebar.slider("Max Depth", 5, 20, 5)

        if st.button("Train Model & Log to MLflow"):
            # Start MLflow Run
            with mlflow.start_run() as run:
                # Train model
                model = XGBClassifier(n_estimators=n_estimators, max_depth=max_depth,learning_rate = learning_rate)
                model.fit(X_train, y_train)
                
                # Calculate metrics
                y_pred = model.predict(X_test)
                report_dict = classification_report(y_test, y_pred, target_names=target_names, output_dict=True)
                report_df = pd.DataFrame(report_dict).transpose()

                # Display the DataFrame using st.dataframe()
                st.dataframe(report_df, use_container_width=True)
                
                #save model
                joblib.dump(model, r"..\model\cls_model.pkl", compress=3)

                # 3. Log to MLflow
                mlflow.log_param("n_estimators", n_estimators)
                mlflow.log_param("max_depth", max_depth)
                mlflow.log_dict(report_dict, artifact_file='classification_report.json')

                st.info(f"Run ID: {run.info.run_id}")

elif page == "Evaluate Loan Application":
    st.subheader('Applicant Details')
    col1, col2, col3, col4 = st.columns(4)
    #Feature selection on sidebar
    def get_user_input():
        user_data = pd.DataFrame(columns=X.columns)
        with col1:
            age = st.number_input('Age', min_value=18, max_value=70, step=1, value=25)

            options = ['Male','Female']
            gender = options.index(st.selectbox('Gender', options))
            options = ['Married','Single']
            marital_status = options.index(st.selectbox('Marital Status',options))
            options = ['High School','Graduate','Professional','Post Graduate']
            education = float(options.index(st.selectbox('Education',options)))
            options = ['Rented','Family','Own']
            house_type = options.index(st.selectbox('House Type',options))
        with col2:
            options = ['Self-employed','Private','Government']
            employment_type = float(options.index(st.selectbox('Employment Type', options)))

            options = ['Startup','Small','Mid-size','Large Indian','MNC']
            company_type = float(options.index(st.selectbox('Company Type',options)))

            monthly_salary = st.number_input('Monthly Salary', min_value=0, max_value=500000, step=1, value=20000)
            years_of_employment = st.number_input('Years of experience', min_value=0, max_value=50, step=1, value=2)
            
        with col3:
            options = ['No','Yes']
            existing_loans = options.index(st.radio("Loan exists",options, horizontal=True))
            
            existing_EMI = st.number_input('Existing EMI', min_value=0, max_value=50000, step=1, value=0)
            liquid_amt = st.number_input('Liquidity/Assets', min_value=0, max_value=2000000, step=1000, value=0)
            monthly_expense = st.number_input('Monthly Expense', min_value=0, max_value=200000, step=1000, value=10000)
        with col4:
            credit_score = st.number_input('Credit Score', min_value=300, max_value=850, step=1, value=650)
            options = ['Home Appliances','Personal Loan','E-commerce Shopping','Education','Vehicle']
            emi_scenario =  st.selectbox('Emi Scenario',options)

            requested_amt = st.number_input('Requested amount', min_value=0, max_value=2000000, step=1000, value=50000)
            tenure = st.number_input('Tenure', min_value=0, max_value=60, step=1, value=12)
        proposed_monthly_emi = requested_amt/tenure
        expense_to_income = round((monthly_expense/monthly_salary)*100,2)
        debt_to_income = 0 
        if existing_EMI > 0:
            debt_to_income =round((existing_EMI/monthly_salary)*100,2)
        
        liquidity_ratio = 0
        if liquid_amt > 0:
            liquidity_ratio = round((liquid_amt/monthly_expense)*100,2)

        emi_buffer_ratio = round((monthly_salary - monthly_expense)*100/monthly_salary, 2)

        Education_EMI = HomeAppliances_EMI = Personal_EMI = Vehicle_EMI = 0
        if emi_scenario == 'Home Appliances':
            HomeAppliances_EMI = 1
        elif emi_scenario == 'Personal Loan':
            Personal_EMI = 1
        elif emi_scenario == 'Education':
            Education_EMI = 1
        elif emi_scenario == 'Vehicle':
            Vehicle_EMI = 1

        #scale the data
        data = {"age": age,"gender": gender,"marital_status":marital_status,"education":education,"monthly_salary":monthly_salary,"employment_type":employment_type,"years_of_employment":years_of_employment,"company_type":company_type,"house_type":house_type,"existing_loans":existing_loans,"credit_score":credit_score,"debt_to_income":debt_to_income,"expense_to_income":expense_to_income,"liquid_amt":liquid_amt,"liquidity_ratio":liquidity_ratio,"emi_buffer_ratio":emi_buffer_ratio,"proposed_monthly_emi":proposed_monthly_emi,"Education EMI": Education_EMI,"Home Appliances EMI": HomeAppliances_EMI,"Personal Loan EMI": Personal_EMI,"Vehicle EMI":Vehicle_EMI}
        data_reg = {"const": 1,"age": age,"gender": gender,"marital_status":marital_status,"education":education,"monthly_salary":monthly_salary,"employment_type":employment_type,"years_of_employment":years_of_employment,"company_type":company_type,"house_type":house_type,"existing_loans":existing_loans,"credit_score":credit_score,"debt_to_income":debt_to_income,"expense_to_income":expense_to_income,"liquid_amt":liquid_amt,"liquidity_ratio":liquidity_ratio,"emi_buffer_ratio":emi_buffer_ratio,"proposed_monthly_emi":proposed_monthly_emi,"Education EMI": Education_EMI,"Home Appliances EMI": HomeAppliances_EMI,"Personal Loan EMI": Personal_EMI,"Vehicle EMI":Vehicle_EMI}
        user_data = pd.DataFrame(data, index=[0])
        user_data_reg = pd.DataFrame(data_reg, index=[0])

        user_data[scaling_cols] = scalar.transform(user_data[scaling_cols])
        user_data_reg[scaling_cols] = scalar.transform(user_data_reg[scaling_cols])
        return user_data, user_data_reg
    
    @st.cache_resource
    def get_model(run_id):
        model_path = "model" # or the name used during log_model
        model_uri = f"runs:/{run_id}/{model_path}"
        return mlflow.pyfunc.load_model(model_uri)
    
    # data = {'age': -0.0055525937881226, 'gender': 0, 'marital_status': 0, 'education': 0.4776731913825139, 'monthly_salary': 0.5063884147466143, 'years_of_employment': -0.8469591294374772, 'house_type': -1.094922049179254, 'existing_loans': 1, 'credit_score': -0.467829128878164, 'proposed_monthly_emi': 3.01898723307958 , 'expense_to_income': 0.8011524791422125, 'liquid_amt': 0.1463225131666687}
    # user_data = pd.DataFrame(data, index=[0])
    user_data, user_data_reg = get_user_input()

    col1, col2 = st.columns(2)
    with col1:
        cls_run_id = st.text_input("Model Run Id for Loan Eligibility","78a5d6208ac64dfe8c07c6fb58c3021e")
    with col2:
        reg_run_id = st.text_input("Model Run Id for Loan Max EMI Amount","b92af19386e944569787e9a9ab4fb9fb")
    target_names = ['Eligible','High_Risk','Not_Eligible']

    if st.button("Predict"):
        cls_model = get_model(cls_run_id)
        if cls_model == None:
            print('Could not get classification model')

        eligibility = cls_model.predict(user_data.iloc[[0]])
        st.write(f"Loan eligibility: {target_names[eligibility[0]]}")

        if target_names[eligibility[0]] == 'Eligible':
            reg_model = get_model(reg_run_id)
            if reg_model == None:
                print('Could not get regression model')
            prediction = reg_model.predict(user_data_reg.iloc[[0]])
            st.write(f"Max EMI approval amount Rs.: { np.expm1(prediction[0])}")