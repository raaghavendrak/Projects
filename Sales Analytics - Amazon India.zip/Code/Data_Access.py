import mysql.connector
import pandas as pd
from sqlalchemy import create_engine
class DataAccess:
    def __init__(self):
        # self.conn = mysql.connector.connect(
        #     host = "localhost",
        #     user = "root",
        #     password = "12345678",
        #     database = "Sales"
        # )
        #self.cursor = self.conn.cursor()
        database_url = "mysql+pymysql://root:12345678@localhost/Sales" 
        self.engine = create_engine(database_url)
    
    def getData(self, query):
        df = pd.read_sql(query,self.engine)
        return df
        
    

    