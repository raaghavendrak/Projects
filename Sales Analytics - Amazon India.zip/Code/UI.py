import streamlit as st
import pandas as pd
import numpy as np
import altair as alt
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import squarify
from datetime import datetime, date
from Data_Access import DataAccess
dataAccess = DataAccess()

df_monthly_rev = pd.DataFrame()
# -----------------------------
# SIDEBAR: DATA INPUT
# -----------------------------
with st.sidebar:
    
    st.title("Navigation")
    page = st.radio(
        "Go to",
        [
            "Homepage Dashboard",
            "Revenue Trend",
            "Monthly Sales",
            "Customer RFM",
            "Payment Method",
            "Product Category",
            "Membership",
            "Geographic analysis",
            "Festive sales",
            "Customer age group and tier",
            "Brands",
            "Product Rating"
        ],
        index=0,
        width='stretch'
    )

    st.divider()


st.title("Sales Dashboard")
# -----------------------------
# PAGE: HOMEPAGE DASHBOARD
# -----------------------------
if page == "Homepage Dashboard":
    df = dataAccess.getData("SELECT count(1) cnt FROM sales.customer where Is_Prime_Member=1")
    st.text(f"Total Membership: {df['cnt'][0]}")

    st.subheader("Products")
    df = dataAccess.getData("SELECT Name FROM sales.product_subcategory")
    st.markdown(" | ".join(df['Name'].tolist()))

    st.subheader("Brands")
    df = dataAccess.getData("SELECT Name FROM sales.product_brand")
    st.markdown(" | ".join(df['Name'].tolist()))

    st.subheader("Delivery Locations")
    df = dataAccess.getData("SELECT Name FROM sales.city")
    st.markdown(" | ".join(df['Name'].tolist()))

    st.subheader("Payment mode")
    df = dataAccess.getData("SELECT Name FROM sales.payment_method")
    st.markdown(" | ".join(df['Name'].tolist()))
   
    
elif page == "Revenue Trend":
    st.subheader("Revenue Trend")
    if 'df_yearly_rev' not in st.session_state:
        sql = """select round((Total_Revenue/10000000),2) 'Total_Revenue(Cr)', Year
            from ( SELECT round(sum(Final_Amount),2) Total_Revenue , YEAR(Order_Date) Year
                FROM sales.transaction t
                left join delivery_status d
                    on t.Delivery_Status_Id = d.id
                where d.Name = 'delivered'
                group by YEAR(Order_Date)) a"""

        df_yearly_rev = dataAccess.getData(sql)
        st.session_state['df_yearly_rev'] = df_yearly_rev
    else: 
        df_yearly_rev = st.session_state['df_yearly_rev']

    df_yearly_rev['Revenue Growth(%)'] = df_yearly_rev['Total_Revenue(Cr)'].pct_change()*100
    
    fig = px.bar(data_frame=df_yearly_rev, x='Year', y='Total_Revenue(Cr)', title="Yearly Revenue")
    plt.tight_layout()
    st.plotly_chart(fig, use_container_width=True)

    fig = px.bar(data_frame=df_yearly_rev, x='Year', y='Revenue Growth(%)', title="Yearly Revenue Growth")
    plt.tight_layout()
    st.plotly_chart(fig, use_container_width=True)

    st.markdown("""
        Summary
        * Revenue increased consistently from 2015 to 2020.
            - Strong expansion period with positive double-digit growth until 2020.
            - Highest growth rate observed in 2016
        * Revenue started declining after 2020.
            - 2025 revenue significantly lower compared to peak years
        """)
# -----------------------------
# PAGE: Monthly Sales
# -----------------------------
elif page == "Monthly Sales":
    st.subheader("Monthly Sales")
    if 'df_monthly_rev' not in st.session_state:
        sql = """select round((Total_Revenue/10000000),2) 'Total_Revenue(Cr)', Year, Month
        from ( SELECT round(sum(Final_Amount),2) Total_Revenue , YEAR(Order_Date) Year, month(Order_Date) month
            FROM sales.transaction t
            left join delivery_status d
                on t.Delivery_Status_Id = d.id
            where d.Name = 'delivered'
            group by YEAR(Order_Date), month(Order_Date)) a"""

        df_monthly_rev = dataAccess.getData(sql)
        st.session_state['df_monthly_rev'] = df_monthly_rev
    else: 
        df_monthly_rev = st.session_state['df_monthly_rev']

    df_monthly_rev['Month_Name'] = pd.to_datetime(df_monthly_rev['Month'], format='%m').dt.strftime('%b')
    fig = px.line(df_monthly_rev, x='Year', y='Total_Revenue(Cr)', color="Month_Name", symbol="Month_Name", title="Monthly Revenue")
    st.plotly_chart(fig, use_container_width=True)

    st.markdown("""
        Summary
        * The business experienced steady growth until 2020, followed by a multi-year slowdown.
        * December remains the strongest revenue-generating month throughout the period.
        """)
    #------------------------------------------------
    pivot_df = df_monthly_rev.pivot_table(
        index='Year',
        columns='Month',
        values='Total_Revenue(Cr)'
    )
    fig, ax = plt.subplots(figsize=(8, 6))
    sns.heatmap(pivot_df, annot=True, fmt='.0f', ax=ax)
    # plt.title("Revenue Heatmap")
    st.pyplot(fig)

elif page == "Customer RFM":
    st.subheader("Customer RFM")
    if 'rfm' not in st.session_state:
        sql="""SELECT Customer_Id, round(Final_Amount,2) Amt_Spent ,Order_Date
        FROM sales.transaction t
        left join delivery_status d
            on t.Delivery_Status_Id = d.id
        where d.Name = 'delivered'"""

        df_cust_purchase = dataAccess.getData(sql)
        snapshot_date = df_cust_purchase['Order_Date'].max() + pd.Timedelta(days=1)
        rfm = df_cust_purchase.groupby('Customer_Id').agg({
            'Order_Date': lambda x: (snapshot_date - x.max()).days,  # Recency
            'Customer_Id': 'count',                                    # Frequency
            'Amt_Spent': 'sum'                                            # Monetary
        })

        rfm.columns = ['Recency', 'Frequency', 'Monetary']

        rfm['R_score'] = pd.qcut(rfm['Recency'], 5, labels=[5,4,3,2,1])
        rfm['F_score'] = pd.qcut(rfm['Frequency'].rank(method='first'), 5, labels=[1,2,3,4,5])
        rfm['M_score'] = pd.qcut(rfm['Monetary'], 5, labels=[1,2,3,4,5])
        rfm['RFM_Score'] = rfm[['R_score','F_score','M_score']].astype(str).sum(axis=1)

        def segment(df):
            if df['RFM_Score'] == '555':
                return 'Champions'
            elif int(df['R_score']) >= 4 and int(df['F_score']) >= 4:
                return 'Loyal Customers'
            elif int(df['R_score'])  <= 2 and int(df['F_score']) <= 2:
                return 'At Risk'
            else:
                return 'Others'

        rfm['Segment'] = rfm.apply(segment, axis=1)

        st.session_state['rfm'] = rfm
    else: 
        rfm = st.session_state['rfm']

    fig, ax = plt.subplots(figsize=(6, 3))
    sns.countplot(data=rfm, x='Segment', ax=ax)
    #plt.xticks(rotation=45)
    #plt.title('Customer Segmentation (RFM)')
    st.pyplot(fig)

    st.markdown("""
        Summary
        * The RFM chart shows that most customers fall into the “Others” segment (~210K), indicating low engagement or value. 
        * A significant portion are “At Risk” (~73K), meaning potential churn. 
        * “Loyal Customers” make up a moderate group (~55K), while “Champions” are very few (~8K).
        """)
    st.text("Key Takeaway: The business has strong opportunities to improve retention and convert more customers into loyal and champion segments.")
    
    pivot = rfm.pivot_table(index='R_score', columns='F_score', values='Monetary', aggfunc='mean')

    fig, ax = plt.subplots(figsize=(8, 6))
    sns.heatmap(pivot, annot=True, fmt='.0f', ax=ax)
    st.pyplot(fig)

elif page == "Payment Method":
    st.subheader("Payment Method")
    if 'df_payment_method' not in st.session_state:
        sql = """select Payment_Method, round(amt/10000000, 2) Amount, Year
            from (select p.Name Payment_Method, sum(Final_Amount) amt, year(Order_Date) Year
                from transaction t
                join payment_method p
                    on t.Payment_Method_Id = p.Id
                left join delivery_status d
                    on t.Delivery_Status_Id = d.id
                where d.Name = 'delivered'
                group by p.Name, year(Order_Date))a"""

        df_payment_method = dataAccess.getData(sql)
        st.session_state['df_payment_method'] = df_payment_method
    else: 
        df_payment_method = st.session_state['df_payment_method']
        
    pivot_df = df_payment_method.pivot(index='Year', columns='Payment_Method', values='Amount')

    ax = pivot_df.plot.area(figsize=(10,6), alpha=0.5)
    # plt.title("Payment Method")
    # plt.ylabel("Revenue (Cr)")
    st.pyplot(ax.get_figure())

    st.markdown("""
        * Digital payment methods outpaced traditional modes
        * UPI became the dominant digital payment mode.
        * COD declined significantly after 2020
        * BNPL showing gradual growth but still relatively smaller share.
        """)
elif page == "Product Category":
    st.subheader("Product Category")
    if 'df_cat_rev' not in st.session_state:
        sql = """select Name as Category_Name, Year, round((Total_Revenue/10000000),2) 'Total_Revenue(Cr)'
            from ( SELECT c.Name, sum(Final_Amount) Total_Revenue , YEAR(Order_Date) Year
                FROM sales.transaction t
                join Product p
                    on t.Product_Id = p.Id
                join product_subcategory c
                    on p.SubCategory_Id = c.Id
                left join delivery_status d
                    on t.Delivery_Status_Id = d.id
                where d.Name = 'delivered'
                group by c.Name, YEAR(Order_Date)) a"""

        df_cat_rev = dataAccess.getData(sql)
        st.session_state['df_cat_rev'] = df_cat_rev
    else: 
        df_cat_rev = st.session_state['df_cat_rev']
    #------------------------------------------------------------------------
    #Market share
    df_cat_rev['Total_Year_Revenue'] = df_cat_rev.groupby('Year')['Total_Revenue(Cr)'].transform('sum')

    df_cat_rev['Market_Share_%'] = (
        df_cat_rev['Total_Revenue(Cr)'] / df_cat_rev['Total_Year_Revenue'] * 100
    )

    #Growth rate
    df_cat_rev = df_cat_rev.sort_values(['Category_Name','Year'])

    df_cat_rev['Growth_%'] = (
        df_cat_rev.groupby('Category_Name')['Total_Revenue(Cr)']
        .pct_change() * 100
    )

    # Growth Plot
    fig = px.line(data_frame=df_cat_rev,  x='Year', y='Growth_%', color='Category_Name', symbol='Category_Name', title='Growth Rate (%)' )
    st.plotly_chart(fig, use_container_width=True)

    fig, axes = plt.subplots(1,2, figsize=(21,7))
    #Revenue
    pivot_df = df_cat_rev.pivot(index='Year', columns='Category_Name', values='Total_Revenue(Cr)').reset_index()
    pivot_df.plot(kind='bar', x='Year', stacked=True , ax=axes[0], ylabel='Revenue (Cr)')
    axes[0].set_title("Yearly Revenue of Products")
   
    # Market Share
    pivot_share = df_cat_rev.pivot(index='Year', columns='Category_Name', values='Market_Share_%')
    pivot_share.plot(kind='bar', stacked=True, ax=axes[1], ylabel='Market Share')
    axes[1].set_title("Yearly Market Share of Products")

    plt.tight_layout()
    st.pyplot(fig)

    #-------------------------------------------------------------------------------------
    st.markdown("""
        Key Takeaways:
        * Smartphone-driven business model — company heavily dependent on one category.
        * Revenue volatility does not significantly alter market share structure.
        * Risk concentration exists due to high smartphone dependency.
        """)
    # donut chart---------------------------------------------------------------------------
    sel_year = st.selectbox("Select Year", df_cat_rev['Year'].unique(), width=250)
    df_year = df_cat_rev[df_cat_rev['Year'] == int(sel_year)]

    fig, ax = plt.subplots(figsize=(5,5))
    wedges, texts, autotexts = ax.pie(
        df_year['Total_Revenue(Cr)'],
        labels=df_year['Category_Name'],
        autopct='%1.1f%%',
        startangle=90
    )
    
    centre_circle = plt.Circle((0,0), 0.60, fc='white')
    ax.add_artist(centre_circle)
    
    ax.set_title(f"{sel_year}")
    plt.tight_layout()
    st.pyplot(fig)

# Tree chart---------------------------------------------------------------------------------------
    df_grouped = df_cat_rev.groupby(['Year','Category_Name'])['Total_Revenue(Cr)'].sum().reset_index()

    labels = (
        df_grouped['Year'].astype(str) + " - " +
        df_grouped['Category_Name'] + "\n₹" +
        df_grouped['Total_Revenue(Cr)'].astype(str)
    )

    fig, ax = plt.subplots(figsize=(20, 7))

    squarify.plot(
        sizes=df_grouped['Total_Revenue(Cr)'],
        label=labels,
        alpha=0.7, ax=ax
    )

    plt.title("Revenue Treemap by Year & Category")
    plt.axis('off')
    st.pyplot(fig)

elif page == "Membership":
    st.subheader("Membership")
    if 'df_memb_rev' not in st.session_state:
        sql = """select round(amt/10000000,2) revenue, cnt membership, Name category, Is_Prime_Member
                from (select sum(t.Final_Amount) amt, count(t.customer_id) cnt, s.Name, c.Is_Prime_Member
                from transaction t
                join customer c
                    on t.customer_id = c.id
                join product p
                    on t.product_id = p.id
                join product_subcategory s
                    on p.subcategory_Id = s.id
                group by s.Name, c.Is_Prime_Member)a"""

        df_memb_rev = dataAccess.getData(sql)
        st.session_state['df_memb_rev'] = df_memb_rev
    else: 
        df_memb_rev = st.session_state['df_memb_rev']

    df_memb_rev['avg_revenue'] = ((df_memb_rev['revenue'] * 10000000)/df_memb_rev['membership']).round(2)
    df_memb_rev["Is_Prime_Member"] = df_memb_rev["Is_Prime_Member"].map({
                                    0: "Non-Prime",
                                    1: "Prime"})
    fig  = px.bar(data_frame=df_memb_rev, x='category', y='avg_revenue', color='Is_Prime_Member', title="Membership average revenue by category") 
    st.plotly_chart(fig)

    st.markdown("""
        Key Takeaways:
        * Prime membership drives higher spending across all categories.
        * High-value categories (TV & Laptops) benefit most from Prime users.
        * Membership conversion could increase revenue significantly.
        * Prime seems especially impactful in premium product segments.
        """)

    fig =  px.bar(data_frame=df_memb_rev, x='category', y='membership', color='Is_Prime_Member', title='Membership accross Product Category')
    st.plotly_chart(fig)

    st.markdown("""
    Key Takeaways:
    * Business heavily dependent on Smartphone category for user base.
    * Other categories contribute marginally to total membership.
    """)

elif page == "Geographic analysis":
    st.subheader("Geographic analysis")
    if 'df_geo_rev' not in st.session_state:
        sql = """select state, city, citytier, round(amt/10000000, 2) revenue, year
            from (select s.name state, y.name city, r.tier citytier, sum(Final_Amount) amt, year(order_date) year
                from transaction t
                join customer c
                    on t.customer_id = c.id
                left join state s
                    on c.state_id = s.id
                left join city y
                    on c.city_id = y.id
                left join Customer_Tier r
                    on c.customer_tier_id = r.Id
                group by s.name, y.name, r.tier, year(order_date)) a"""

        df_geo_rev = dataAccess.getData(sql)
        st.session_state['df_geo_rev'] = df_geo_rev
    else: 
        df_geo_rev = st.session_state['df_geo_rev']

    df_tier_grp = df_geo_rev.groupby(['year','citytier']).sum('revenue').reset_index()
    pivot_tier = df_tier_grp.pivot(index='year', columns=['citytier'], values='revenue')

    
    fig = px.bar(data_frame=df_tier_grp,x='year', y='revenue', color= 'citytier', title="Yearly revenue based on city tier")
    plt.tight_layout()
    st.plotly_chart(fig)

    st.markdown("""
        Key Takeaways:
        * Business is Metro-dependent.
        * Revenue structure remains stable across tiers (no drastic share shifts).
        * Tier 2 & Rural offer long-term growth opportunities.
        """)

    df_city_grp = df_geo_rev.groupby(['year','city']).sum('revenue').reset_index()
    fig = px.line(df_city_grp, x='year', y='revenue', color="city", symbol="city", title="Yearly revenue by city")
    plt.tight_layout()
    st.plotly_chart(fig, use_container_width=True)

    st.markdown("""
        Key Takeaways:
        * Major metros drive the majority of revenue.
        * Smaller cities show gradual growth but lower base impact.
        """)

elif page == "Festive sales":
    st.subheader("Festive sale")
    if 'df_fest_rev' not in st.session_state:
        sql = """select festive_name, a.year, round(revenue/(datediff(ma,mi) * 100000), 2) 'avg_revenue(lk)', avg_amt
            from (select min(order_date) mi,max(Order_Date) ma, f.name festive_name, year(Order_Date) year, sum(Final_Amount) revenue
                    from transaction t 
                    join festive_sale f
                        on t.Festive_Sale_Id = f.id
                    where Festive_Sale_Id is not null
                    group by f.name, year(Order_Date))a
            join (select round(sum(Final_Amount)/(365*100000),2) avg_amt, year(order_date) year
                    from transaction
                    where IFNULL(Is_Festival_Sale, false) = false 
                    group by year(Order_Date)) b
                on a.year = b.year"""

        df_fest_rev = dataAccess.getData(sql)
        st.session_state['df_fest_rev'] = df_fest_rev
    else: 
        df_fest_rev = st.session_state['df_fest_rev']
    
    pivot_fest = df_fest_rev.pivot(index='year', columns='festive_name', values='avg_revenue(lk)')
    pivot_fest = pivot_fest.merge(df_fest_rev.drop_duplicates(subset=['year','avg_amt'])[['year','avg_amt']], left_on='year', right_on='year')
    unpivot_fest = pivot_fest.melt(id_vars='year', value_vars=['Amazon Great Indian Festival', 'Back to School', 'Diwali Sale',
       'Holi Festival', 'Prime Day', 'Republic Day Sale', 'Summer Sale',
       'Valentine Sale', 'avg_amt'])
    fig = px.line(unpivot_fest, x='year', y='value', color="variable", symbol="variable", 
                  title='Yearly festive sale revenue',
                 labels={'year': 'Year', 'value': 'avg_revenue(lakhs)'})
    plt.tight_layout()
    st.plotly_chart(fig, use_container_width=True)

    st.markdown("""
        Key Takeaways:
        * Festive sales generate 10–15x more revenue than non-festive periods.
        * Non-festive revenue is stable but not a major contributor compared to big sale events.
        * Business is highly dependent on promotional events for revenue spikes.
        * Prime Day dominates every year.
        * All sales follow almost the same growth curve, indicating broader market trends rather than event-specific fluctuations.
        """)

elif page == "Customer age group and tier":
    st.subheader("Customer age group and tier")
    if 'df_age_rev' not in st.session_state:
        sql = """select a.Age_Group, s.Tier, y.Name category, count(customer_id) customers, round(sum(Final_Amount)/10000000, 2)  Revenue
            from transaction t
            join customer c
                on t.customer_id = c.id
            join customer_age_group a
                on c.Customer_Age_Group_Id = a.Id
            left join Customer_SpendingTier s
                on c.Customer_SpendingTier_Id = s.id
            join product p
                on t.product_id = p.id
            join product_subcategory y
                on p.SubCategory_Id = y.id
            group by a.Age_Group, s.Tier, y.Name"""

        df_age_rev = dataAccess.getData(sql)
        st.session_state['df_age_rev'] = df_age_rev
    else: 
        df_age_rev = st.session_state['df_age_rev']

    fig, axes = plt.subplots(1,2, figsize=(14,5))
    sns.barplot(df_age_rev.groupby('Age_Group').sum(['cutomers','revenue']).reset_index(), x='Age_Group', y='customers', ax=axes[0])
    sns.barplot(df_age_rev.groupby('Age_Group').sum(['cutomers','revenue']).reset_index(), x='Age_Group', y='Revenue', ax=axes[1])
    plt.tight_layout()
    st.pyplot(fig)

    fig, axes = plt.subplots(1,2, figsize=(14,5))
    sns.barplot(df_age_rev.groupby('Tier').sum(['cutomers','revenue']).reset_index(), x='Tier', y='customers', ax=axes[0])
    sns.barplot(df_age_rev.groupby('Tier').sum(['cutomers','revenue']).reset_index(), x='Tier', y='Revenue', ax=axes[1])
    plt.tight_layout()
    st.pyplot(fig)

    st.markdown("""
        Key Takeaways:
        * The 26–35 age group has the highest number of customers and generates the most revenue.
        * Customer count and revenue steadily decline with age, with 55+ contributing the least.
        * The Standard tier has the most customers and generates the highest revenue.
        * Premium generates strong revenue despite fewer customers than Standard.
        """)

    sel_agegrp = st.selectbox("Select Age Group", df_age_rev['Age_Group'].unique(), width=250)
    sel_tier = st.selectbox("Select Tier", df_age_rev['Tier'].unique(), width=250)
    cond = (df_age_rev['Age_Group'] == sel_agegrp) & (df_age_rev['Tier'] == sel_tier)

    fig, axes = plt.subplots(figsize=(8,6))
    sns.barplot(df_age_rev[cond], x='category', y='Revenue', ax=axes)
    plt.tight_layout()
    st.pyplot(fig)

elif page == "Brands":
    st.subheader("Brands")
    st.text("Sales and revenue of different brands")
    if 'df_brand_rev' not in st.session_state:
        sql = """select s.name category, b.name brand, sum(t.Quantity)/1000 quantity, round(sum(Final_Amount)/10000000,2) revenue
            from transaction t
            join product p
                on t.product_id = p.id
            join product_subcategory s
                on p.SubCategory_Id = s.id
            join product_brand b
                on p.Brand_Id = b.Id
            group by  s.name,b.name """

        df_brand_rev = dataAccess.getData(sql)
        st.session_state['df_brand_rev'] = df_brand_rev
    else: 
        df_brand_rev = st.session_state['df_brand_rev']
    
    fig, axes = plt.subplots(1,2, figsize=(14,7))
    sel_category = st.selectbox("Select Category", df_brand_rev['category'].unique(), width=250)
    sns.barplot(df_brand_rev[df_brand_rev['category'] == sel_category], x='brand', y='quantity', ax=axes[0])
    sns.barplot(df_brand_rev[df_brand_rev['category'] == sel_category], x='brand', y='revenue', ax=axes[1])
    plt.tight_layout()
    st.pyplot(fig)

elif page == "Product Rating":
    st.subheader("Product Rating")
    st.text("Sales and revenue of rated products")
    if 'df_rating_rev' not in st.session_state:
        sql = """select p.Rating, s.name category, sum(Quantity)/1000 quantity, round(sum(Final_Amount)/10000000,2)  Revenue
        from transaction t
        join product p
            on t.Product_Id = p.id
        join product_subcategory s
            on p.SubCategory_Id = s.Id
        group by p.Rating, s.name"""

        df_rating_rev = dataAccess.getData(sql)
        st.session_state['df_rating_rev'] = df_rating_rev
    else: 
        df_rating_rev = st.session_state['df_rating_rev']

    sel_cat = st.selectbox("Select Category", df_rating_rev['category'].unique(), width=250)
    fig, axes = plt.subplots(1,2, figsize=(14,7))
    sns.barplot(df_rating_rev[df_rating_rev['category'] == sel_cat] , x='Rating', y='quantity', ax=axes[0])
    sns.barplot(df_rating_rev[df_rating_rev['category'] == sel_cat] , x='Rating', y='Revenue', ax=axes[1])
    plt.tight_layout()
    st.pyplot(fig)

    st.markdown("""
        Key Takeaways:
        * Higher rating = Higher sales (clear positive correlation).
        * Improving product quality and customer satisfaction can directly boost sales volume.
    """)